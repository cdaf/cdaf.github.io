# This is an example script which only return WINDOWS, i.e. the on-domain default 
return 'WINDOWS'