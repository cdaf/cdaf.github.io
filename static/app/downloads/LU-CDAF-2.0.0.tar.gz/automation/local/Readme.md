Local Execution
===============

Local execution does not limit the results of task execution to the local host.

remoteTasks
-----------

These are remote task launching scripts.
