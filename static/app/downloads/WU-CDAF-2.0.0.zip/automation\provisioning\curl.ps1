
Write-Host "Download & install using base.ps1 curl"
