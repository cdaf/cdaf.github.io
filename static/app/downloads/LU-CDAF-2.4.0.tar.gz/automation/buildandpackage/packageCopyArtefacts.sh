#!/usr/bin/env bash
set -e
scriptName=$(basename $0)

function exitIfCR {
	echo "$0 : Exception! $1 contains a return character!"
	exit 6612
}  

# Arguments are not validated in sub-scripts, only at entry point
DRIVER=$1
WORK_DIR_DEFAULT=$2
AUTOMATIONROOT=$3

if [ -f  "$DRIVER" ]; then
	echo; echo "[$scriptName] Load variables from manifest"; echo
	fileWithoutComments=$(sed -e 's/#.*$//' -e '/^ *$/d' manifest.txt)
	while read -r LINE; do
		IFS="\="
		read -ra array <<< "$LINE"
		propertiesList="${array[0]}=\"${array[1]}\""
		echo "  ${propertiesList}"
		eval "$propertiesList"
	done < <(echo "$fileWithoutComments")
	unset IFS

	grep -q $'\r' $DRIVER && exitIfCR $DRIVER
	echo; echo "[$scriptName] Copy artifacts defined in $DRIVER"; echo
	config=$(cat ${DRIVER}) # cat will read all lines, native READ will miss lines that done have line-feed
	while read -r line; do

		#deleting lines starting with # ,blank lines ,lines with only spaces
		ARTIFACT=$(sed -e 's/#.*$//' -e '/^ *$/d' <<< $line)

		if [ ! -z "$ARTIFACT" ]; then
			set -f # disable globbing, i.e. do not preprocess definitions containing wildcards
			# There must be a more elegant way to do this, but the current implementation is to overcome variable expansion when containing / character(s)
			declare -a artArray=${ARTIFACT};
			x=0
			unset source
			unset flat
			unset recurse
			unset copyParent
			for element in ${artArray[@]}; do 
				# First element in array is treated as the source
				if [ $x -eq 0 ]; then
					source=$(echo "$element");
				else
					# options are case insensitive
					option=$(echo "$element" | tr '[a-z]' '[A-Z]')
					if [ "$option" == "-RECURSE" ]; then recurse="on"; fi
					if [ "$option" == "-FLAT" ]; then flat="on"; fi
				fi
				x=$((x + 1))
			done

			# In CDAF for Windows (PowerShell), recursive processing is explicitly  
	 		# coded, in bash it is a native function, for consistency -recurse is looked for
	 		# but no action performed, in the future I may support -recurse & -flat to allow a
	  		# complete directory subtree flattening. 		
			if [ "$flat" == "on" ]; then
				targetPath="$WORK_DIR_DEFAULT"
				if [ -d "$source" ]; then
					source+="/*"
				fi
			else
				# Only set the target path for files, directories will be created as part of recursive copy
				if [ -d $source ]; then
					targetPath="$WORK_DIR_DEFAULT"
					# Copy the complete path into the target 				
					if [ "$recurse" == "on" ]; then
						copyParent="--parents "
					fi
				else
					targetPath="$WORK_DIR_DEFAULT/$(dirname "$source")/"
				fi
				# The target maybe a parent path of an existing artefact definition, so test for existing 
				if [ ! -d "$targetPath" ]; then
					command="mkdir -pv $targetPath"
					eval $command
					exitCode=$?
					if [ $exitCode -ne 0 ]; then
						echo "[$scriptName] $command failed! Exit code = $exitCode."
						exit $exitCode
					fi
				fi
			fi
			command="cp $copyParent -av $source $targetPath"
			set +f # enable globbing for copy operation
			eval "cp $copyParent -av $source $targetPath"
			exitCode=$?
			if [ $exitCode -ne 0 ]; then
				echo "[$scriptName] $command failed! Exit code = $exitCode."
				exit $exitCode
			fi
			
			artefactList=$(echo $artefactList ${ARTIFACT##*/})
		fi
		
	done < <(echo "$config")

	if [ -z "$artefactList" ]; then
		echo "[$scriptName]   [WARN] No artefacts processed from definition file ($DRIVER)."
	fi
			
fi
