# Continuous Delivery Automation Framework (CDAF)

For principles and usage guidance see [https://cdaf.io](https://cdaf.io/10-cdaf/index.html).

For the complete set of samples and provisioning helpers, see [GitHub](https://github.com/cdaf/linux).

For related blog, see [LinkedIn articles](https://www.linkedin.com/in/jules-clements-842b589/recent-activity/articles/).
