#!/usr/bin/env bash
function executeExpression {
	echo "[$scriptName] $1"
	eval $1
	exitCode=$?
	# Check execution normal, anything other than 0 is an exception
	if [ "$exitCode" != "0" ]; then
		echo "$0 : Exception! $EXECUTABLESCRIPT returned $exitCode"
		exit $exitCode
	fi
}  

scriptName='tomcat.sh'

echo "[$scriptName] --- start ---"
version="$1"
if [ -z "$version" ]; then
	version='8.5.4'
	echo "[$scriptName]   version : $version (default)"
else
	echo "[$scriptName]   version : $version"
fi

appRoot="$2"
if [ -z "$appRoot" ]; then
	appRoot='/opt/apache'
	echo "[$scriptName]   appRoot : $appRoot (default)"
else
	echo "[$scriptName]   appRoot : $appRoot"
fi

# Set parameters
tomcat="apache-tomcat-${version}"
echo "[$scriptName]   tomcat  : $tomcat"

if [ -z "$(getent passwd tomcat)" ]; then
	# Create and Configure Deployment user
	centos=$(uname -a | grep el)
	if [ -z "$centos" ]; then
		echo "[$scriptName] Create the runtime user (tomcat) Ubuntu/Debian"
		executeExpression "sudo adduser --disabled-password --gecos \"\" tomcat"
	else
		echo "[$scriptName] Create the runtime user (tomcat) CentOS/RHEL"
		executeExpression "sudo adduser tomcat"
	fi
else
	echo "[$scriptName] Tomcat user (tomcat) alrady exists, no action required."
fi

echo
echo "[$scriptName] Create application root directory and change to runtime directory"
executeExpression "sudo mkdir -p $appRoot"
executeExpression "cd $appRoot"

echo
echo "[$scriptName] Copy media and extract"
executeExpression "cp -v \"/vagrant/.provision/${tomcat}.tar.gz\" ."
executeExpression "tar -zxf ${tomcat}.tar.gz"

echo
echo "[$scriptName] Make all objects executable and owned by tomcat service account"
executeExpression "sudo chown -R tomcat:tomcat $tomcat"
executeExpression "sudo chmod 755 -R $tomcat"

echo
echo "[$scriptName] Retain the default tomcat console"
cd $tomcat
executeExpression "mv -v webapps/ROOT/ webapps/console"

echo
echo "[$scriptName] Start the server, as tomcat user"
executeExpression "sudo ln -sv $appRoot/$tomcat /opt/tomcat"
executeExpression "sudo -H -u tomcat bash -c \'/opt/tomcat/bin/startup.sh\'"

echo "[$scriptName] --- end ---"
