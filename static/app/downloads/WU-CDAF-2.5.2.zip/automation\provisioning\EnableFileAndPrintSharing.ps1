# Common expression logging and error handling function, copied, not referenced to ensure atomic process
function executeExpression ($expression) {
	$error.clear()
	Write-Host "$expression"
	try {
		Invoke-Expression $expression
	    if(!$?) { Write-Host "[$scriptName] `$? = $?"; exit 1 }
	} catch { echo $_.Exception|format-list -force; exit 2 }
    if ( $error ) { Write-Host "[$scriptName] `$error[0] = $error"; exit 3 }
    if (( $LASTEXITCODE ) -and ( $LASTEXITCODE -ne 0 )) { Write-Host "[$scriptName] `$LASTEXITCODE = $LASTEXITCODE "; exit $LASTEXITCODE }
}

$scriptName = 'EnableFileAndPrintSharing.ps1'
Write-Host "`n[$scriptName] ---------- start ----------"

executeExpression "DISM /Online /Enable-Feature /FeatureName:File-Services /All"
executeExpression "netsh advfirewall firewall set rule group='File and Printer Sharing' new enable=Yes"

Write-Host "`n[$scriptName] ---------- stop ----------"
exit 0