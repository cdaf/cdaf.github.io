NuGet for Octopus
=================

To extend CDAF to support Octopus, a NuGet wrapper needs to be applied, to use the CDAF NuGet wrapper:

1. copy CDAF.nuspec to the root of the solution
2. copy wrap.tsk to the root of automation solution folder
3. copy the tools folder to the automation solution folder