#!/usr/bin/env bash
set -e

# Elevated (sudo) call from Deploy

DEFINITION="ENVIR_DEF=\"$1\""
echo "$0 : Add $DEFINITION to /etc/environment"
echo $DEFINITION >> /etc/environment

