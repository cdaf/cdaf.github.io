#!/usr/bin/env bash
set -e
# This is an example script which only return LINUX, i.e. the default 
echo 'LINUX'